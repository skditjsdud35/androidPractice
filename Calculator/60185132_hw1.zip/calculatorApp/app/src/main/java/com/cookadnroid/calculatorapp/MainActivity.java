package com.cookadnroid.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Edit1, Edit2;
    Button Add, Sub, Mul, Div;
    TextView textResult;
    String num1, num2;
    Integer result;
    Button[] numButtons = new Button[10];
    Integer[] numBtnIDs = {R.id.btnNum0, R.id.btnNum1, R.id.btnNum2, R.id.btnNum3, R.id.btnNum4, R.id.btnNum5, R.id.btnNum6, R.id.btnNum7, R.id.btnNum8, R.id.btnNum9};
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Calculator");

        Edit1 = (EditText) findViewById(R.id.Edit1);
        Edit2 = (EditText) findViewById(R.id.Edit2);
        Add = (Button) findViewById(R.id.Add);
        Sub = (Button) findViewById(R.id.Sub);
        Mul = (Button) findViewById(R.id.Mul);
        Div = (Button) findViewById(R.id.Div);
        textResult = (TextView) findViewById(R.id.textResult);


        Add.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1){
                num1 = Edit1.getText().toString();
                num2 = Edit2.getText().toString();

                if (num1.trim().equals("")|| num2.trim().equals("")){
                    Toast.makeText(getApplicationContext(),"값을 입력하세요",Toast.LENGTH_SHORT)
                            .show();
                }else {
                    result = Integer.parseInt(num1) + Integer.parseInt(num2);
                    textResult.setText(result.toString());
                }
                return  false;
            }
        });
        Sub.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1){
                num1 = Edit1.getText().toString();
                num2 = Edit2.getText().toString();

                if (num1.trim().equals("")|| num2.trim().equals("")){
                    Toast.makeText(getApplicationContext(),"값을 입력하세요",Toast.LENGTH_SHORT)
                            .show();
                }else {
                    result = Integer.parseInt(num1) - Integer.parseInt(num2);
                    textResult.setText(result.toString());
                }
                return  false;
            }
        });

        Mul.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1){
                num1 = Edit1.getText().toString();
                num2 = Edit2.getText().toString();

                if (num1.trim().equals("")|| num2.trim().equals("")){
                    Toast.makeText(getApplicationContext(),"값을 입력하세요",Toast.LENGTH_SHORT)
                            .show();
                }else {
                    result = Integer.parseInt(num1) * Integer.parseInt(num2);
                    textResult.setText(result.toString());
                }
                return  false;
            }
        });

        Div.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1){
                num1 = Edit1.getText().toString();
                num2 = Edit2.getText().toString();
                if (num1.trim().equals("")|| num2.trim().equals("")) {
                    Toast.makeText(getApplicationContext(), "값을 입력하세요", Toast.LENGTH_SHORT)
                            .show();
                }else if(Edit2.getText().toString().equals("0")){
                    Toast.makeText(getApplicationContext(),"0으로 나눌 수 없음",Toast.LENGTH_SHORT)
                            .show();
                }else {
                    result = Integer.parseInt(num1) / Integer.parseInt(num2);
                    textResult.setText(result.toString());
                }
                return false;
            }
        });
        for (i = 0; i <numBtnIDs.length; i++) {
            numButtons[i] = (Button) findViewById(numBtnIDs[i]);
        }
        for (i = 0; i <numBtnIDs.length; i++){
            final int index;
            index = i;

            numButtons[index].setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){
                    if (Edit1.isFocused() == true){
                        num1 = Edit1.getText().toString()
                                + numButtons[index].getText().toString();
                        Edit1.setText(num1);
                    }else if (Edit2.isFocused() == true){
                        num2 = Edit2.getText().toString()
                                + numButtons[index].getText().toString();
                        Edit2.setText(num2);
                    }else {
                        Toast.makeText(getApplicationContext(),"EditText를 선택하세요", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}