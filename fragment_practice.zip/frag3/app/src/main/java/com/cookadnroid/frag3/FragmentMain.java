package com.cookadnroid.frag3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragmentMain extends Fragment {
    EditText edtText;
    Button btnRed, btnBlue, btnGreen;
    FragmentA fragmentA;
    FragmentB fragmentB;
    FragmentC fragmentC;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main, container, false);

        edtText = (EditText) v.findViewById(R.id.edtText);
        btnBlue = (Button) v.findViewById(R.id.btnBlue);
        btnRed = (Button) v.findViewById(R.id.btnRed);
        btnGreen = (Button) v.findViewById(R.id.btnGreen);



        btnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle data = new Bundle();
                data.putString("text", edtText.getText().toString());


                fragmentA = new FragmentA();
                fragmentA.setArguments(data);

                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.add(R.id.container_main, fragmentA);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putString("text", edtText.getText().toString());


                fragmentB = new FragmentB();
                fragmentB.setArguments(data);

                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.add(R.id.container_main, fragmentB);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        btnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putString("text", edtText.getText().toString());


                fragmentC = new FragmentC();
                fragmentC.setArguments(data);

                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.add(R.id.container_main, fragmentC);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });
        return v;
    }
}



