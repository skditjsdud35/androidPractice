package com.cookadnroid.frag3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentB extends Fragment {
    String text;
    EditText edtText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_b,container,false);

        edtText = (EditText)v.findViewById(R.id.edit_text);

        Bundle data = getArguments();
        text = data.getString("text");
        edtText.setText(data.getString("text"));

        return v;
    }
}
